class Univ < ActiveRecord::Base
end
