class MyRailsBoardRow < ActiveRecord::Base
end
