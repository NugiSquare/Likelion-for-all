class QuestionPost < ActiveRecord::Base
end
