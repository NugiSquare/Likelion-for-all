require 'test_helper'

class QuestionPostTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
