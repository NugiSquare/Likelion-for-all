require 'test_helper'

class MyRailsBoardRowTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
